<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @author: Swarnava Banerjee
 * FileName: User.php
 * Function: Controller for manging users login
 * Created: 21/03/2022
 *
 *
 * Dependencies:
 *
 * Modified on: 21/03/2022
 * Modified by:Swarnava Banerjee
 *
 * Scripting language: PHP5
 * Tested on: PHP version  7.2.25, Apache 2, Windows.
 *
 */

class User extends MY_Controller {

	function __construct()
	{		
		parent::__construct();

		$this->load->module('layout');	
		$this->load->model('user_model');
		$this->load->model('role_model');
		$this->load->model('designation_model');

	}

	// public function auth()
	// {
	// 	$this->layout->load($data)->render();
	// }

	public function auth(){
		if($_POST){
			$uname = $this->input->post('uname');
			$password = $this->input->post('password');
			$data['received'] = $this->user_model->check_login($uname,$password);
			//echo $data['received'][0]->id;die;
			//print_r($data['received']);die;
			if(sizeof($data['received']) > 0){
				//echo 'Yes';die;
				$this->session->set_userdata('id', $data['received'][0]->id);
				$this->session->set_userdata('user_name', $data['received'][0]->user_name);
				redirect('/user/dashboard');
			}else{
				//echo 'No';die;
				$this->session->set_flashdata('error_msg', 'Invalid Username or Password.');
				$this->layout->load($data)->render();
			}
		}else{
			$this->layout->load($data)->render();
		}
	}
	public function dashboard(){
		$data='';
		$this->layout->load($data)->render();
	}
	
	
	public function signout()
	{
		$this->session->sess_destroy();
		redirect('user/auth');
	}
	public function index()
	{
        $data['users']= $this->user_model->get_all_users();
		//$data['users']= $this->user_model->joining_tables();
		$this->layout->load($data)->render();
	}
    public function add(){
        $data['roles']=$this->role_model->get_all_roles();
		$data['designation']= $this->designation_model->get_all_designation();
		//echo '<pre>';print_r($data);die;
		$this->layout->load($data)->render();
    }
	
	public function insert_user() {  
        if($this->input->post())
            {
                $data['user_name']=$this->input->post('user_name');
				$data['password']=$this->input->post('password');
				$data['first_name']=$this->input->post('first_name');
				$data['middle_name']=$this->input->post('middle_name');
				$data['last_name']=$this->input->post('last_name');
				$data['email']=$this->input->post('email');
				$data['role_id']=$this->input->post('role_id');
				$data['designation']=$this->input->post('designation');
				//echo '<pre>';print_r($data['designation']);die;
				$data['status']=$this->input->post('is_active');
				$data['created_by']=$this->session->userdata('id');
				//$data['created_at']=$this->input->post('created_at');
				$data['updated_by']=$this->session->userdata('id');
				//$data['updated_at']=$this->input->post('updated_at');

				//echo '<pre>';print_r($data);die;
                
                $response=$this->user_model->add_users($data);
                if($response==true){
                    $messge = array('message' => 'User inserted successfull.','class' => 'alert alert-success fade in');  
                    $this->session->set_flashdata('user', $messge);
                    redirect('/user/user');

                }
                else{
                    $messge = array('message' => 'Something went wrong...!!!','class' => 'alert alert-danger fade in');  
                    $this->session->set_flashdata('user', $messge);
                    redirect('/user/user');
                }
            }          
        }
		public function edit() {  
			$id = $this->uri->segment(4);
			$data['roles']=$this->role_model->get_all_roles();
			$data['designation']= $this->designation_model->get_all_designation();
			$data['user_details']=$this->user_model->get_user_by_id($id);
			$this->layout->load($data)->render();         
		}
		public function update_user(){
			$id = $this->input->post('user_id');
			$data['user_name']=$this->input->post('user_name');
			$data['password']=$this->input->post('password');
			$data['first_name']=$this->input->post('first_name');
			$data['middle_name']=$this->input->post('middle_name');
			$data['last_name']=$this->input->post('last_name');
			$data['email']=$this->input->post('email');
			$data['role_id']=$this->input->post('role_id');
			$data['designation']=$this->input->post('designation');
			//echo '<pre>';print_r($data['designation']);die;
			$data['status']=$this->input->post('is_active');
			$data['created_by']=$this->session->userdata('id');
			//$data['created_at']=$this->input->post('created_at');
			$data['updated_by']=$this->session->userdata('id');
			//$data['updated_at']=$this->input->post('updated_at');
			//echo '<pre>';print_r($data);die;
			$response=$this->user_model->update_users($data,$id);
			if($response==true){
				$messge = array('message' => 'User updated  successfull.','class' => 'alert alert-success fade in');  
				$this->session->set_flashdata('user', $messge);
				redirect('/user/user');
			}
			else{
				$messge = array('message' => 'Something went wrong...!!!','class' => 'alert alert-danger fade in');  
				$this->session->set_flashdata('user', $messge);
				redirect('/user/user');
			}
		}
		public function remove_user(){
		
				$user_id = $this->uri->segment(4);
				$rec = $this->user_model->remove_user($user_id);
				$messge = array('message' => 'User successfully deleted','class' => 'alert alert-danger fade in');  
					$this->session->set_flashdata('user', $messge);
				return $rec;
		
			}

}
/*End of file */