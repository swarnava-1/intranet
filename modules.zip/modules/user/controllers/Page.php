<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @author: Swarnava Banerjee
 * FileName: User.php
 * Function: Controller for manging users login
 * Created: 21/03/2022
 *
 *
 * Dependencies:
 *
 * Modified on: 21/03/2022
 * Modified by:Swarnava Banerjee
 *
 * Scripting language: PHP5
 * Tested on: PHP version  7.2.25, Apache 2, Windows.
 *
 */

class Page extends MY_Controller {

	function __construct()
	{		
		parent::__construct();

		$this->load->module('layout');	
		$this->load->model('page_model');
	}

	public function index()
	{
        $data['pages']= $this->page_model->get_all_pages();
		$this->layout->load($data)->render();
	}
    public function add(){
        
		$this->layout->load($data)->render();
    }
    public function insert_page() {
       
        if($this->input->post())
            {
                $data['sl_no']=$this->input->post('sl_no');
                $data['location']=$this->input->post('location');
                $data['created_by']=$this->session->userdata('id');
                $data['updated_by']=$this->session->userdata('id');
                //echo '<pre>';print_r($data);die;
                $response=$this->page_model->add_pages($data);
                if($response==true){
                    $messge = array('message' => 'Page inserted successfull.','class' => 'alert alert-success fade in');  
                    $this->session->set_flashdata('page', $messge);
                    redirect('/user/page');

                }
                else{
                    $messge = array('message' => 'Something went wrong...!!!','class' => 'alert alert-danger fade in');  
                    $this->session->set_flashdata('page', $messge);
                    redirect('/user/page');
                    
                }
            }          
        }
        public function edit() {  
            $id = $this->uri->segment(4);
            $data['page_details']=$this->page_model->get_page_by_id($id);
            //echo '<pre>';print_r($data['role_details']);die;
            $this->layout->load($data)->render();         
        }
    
        public function update_page(){
            
            $id = $this->input->post('page_id');
            $data['sl_no']=$this->input->post('sl_no');
            $data['location']=$this->input->post('location');
            $data['created_by']=$this->session->userdata('id');
            $data['updated_by']=$this->session->userdata('id');
            //echo '<pre>';print_r($data);die;
            $response=$this->page_model->update_page($data,$id);
            if($response==true){
                $messge = array('message' => 'page updated  successfull.','class' => 'alert alert-success fade in');  
                $this->session->set_flashdata('page', $messge);
                redirect('/user/page');
            }
            else{
                $messge = array('message' => 'Something went wrong...!!!','class' => 'alert alert-danger fade in');  
                $this->session->set_flashdata('page', $messge);
                redirect('/user/page');
            }
        }
        public function remove_page(){
            $page_id = $this->uri->segment(4);
            $rec = $this->page_model->remove_page($page_id);
            $messge = array('message' => 'Page successfully deleted','class' => 'alert alert-danger fade in');  
            $this->session->set_flashdata('page', $messge);
            return $rec;
    
        }        
}