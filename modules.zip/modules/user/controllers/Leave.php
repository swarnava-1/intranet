<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @author: Swarnava Banerjee
 * FileName: User.php
 * Function: Controller for manging users login
 * Created: 21/03/2022
 *
 *
 * Dependencies:
 *
 * Modified on: 21/03/2022
 * Modified by:Swarnava Banerjee
 *
 * Scripting language: PHP5
 * Tested on: PHP version  7.2.25, Apache 2, Windows.
 *
 */

class Leave extends MY_Controller {

	function __construct()
	{		
		parent::__construct();

		$this->load->module('layout');	
		$this->load->model('leave_model');
        $this->load->model('user_model');
	}

	public function index()
	{
        $user_id=$this->session->userdata('id');
        $data['leave']= $this->leave_model->get_all_leave();
        $data['leaves']= $this->leave_model->get_all_total_leave($user_id);
       // echo'<pre>';print_r($data['leaves']);die;
		$this->layout->load($data)->render();
	}
    public function add(){
        $user_id=$this->session->userdata('id');
        $data['users']= $this->leave_model->get_all_users($user_id);
		$this->layout->load($data)->render();
    }
    public function insert_leave() {  
        if($this->input->post())
            {
                $user_id=$this->session->userdata('id');
                $data['leave_type']=$this->input->post('leave_type');
				$data['leave_purpose']=$this->input->post('leave_purpose');
				$data['leave_date_from']=$this->input->post('leave_date_from');
				$data['leave_date_to']=$this->input->post('leave_date_to');
                $approved_to =implode(",",$this->input->post('approved_to'));
                $data['approved_to']=$approved_to;
				$data['leave_status']=$this->input->post('leave_status');
				$data['approved_by']=$this->input->post('approved_by');
                $response=$this->leave_model->add_leave($data);
                if($response==true){
                    if($data['leave_status']==1)
                    {
                        if($data['leave_type']=='medical')
                        {
                        $diff= strtotime($data['leave_date_from'])-strtotime($data['leave_date_to']);
                        echo $day= abs(round($diff / 86400)) + 1;
                        $curent_day_count_for_medical = $this->leave_model->get_curent_leave($data['leave_type'],$user_id);
                        $medical_leave=$curent_day_count_for_medical[0]->leave_count;
                        $now_date_count =  $medical_leave-$day;
                        $day_data = array('leave_count'=>$now_date_count);
                        $this->leave_model->update_day($day_data,$user_id,$data['leave_type']);
                        } else {
                        $diff= strtotime($data['leave_date_from'])-strtotime($data['leave_date_to']) ;
                        $day= abs(round($diff / 86400)) + 1;
                        $curent_day_count_for_casual = $this->leave_model->get_curent_leave($data['leave_type'],$user_id);
                        $casual_leave=$curent_day_count_for_casual[0]->leave_count;
                        $now_date_count =  $casual_leave-$day;
                        $day_data = array('leave_count'=>$now_date_count);
                        $this->leave_model->update_day($day_data,$user_id,$data['leave_type']);
                        }
                    }
                    $messge = array('message' => 'leave updated  successfull.','class' => 'alert alert-success fade in');  
                    $this->session->set_flashdata('leave', $messge);
                    redirect('/user/leave');
                }          
            }
            }          
        
        public function edit() {  
            $id = $this->uri->segment(4);
            $user_id=$this->session->userdata('id');
            $data['users']= $this->leave_model->get_all_users($user_id);
            $data['leave_details']=$this->leave_model->get_leave_by_id($id);
            //echo '<pre>';print_r($data['role_details']);die;
            $this->layout->load($data)->render();         
        }
    
        public function update_leave(){
            $id = $this->input->post('leave_id');
            $user_id=$this->session->userdata('id');
            $data['leave_type']=$this->input->post('leave_type');
            $data['leave_purpose']=$this->input->post('leave_purpose');
            $data['leave_date_from']=$this->input->post('leave_date_from');
            $data['leave_date_to']=$this->input->post('leave_date_to');
            $approved_to =implode(",",$this->input->post('approved_to'));
            $data['approved_to']=$approved_to;
            $data['leave_status']=$this->input->post('leave_status');
            $data['approved_by']=$this->input->post('approved_by');

            $response=$this->leave_model->update_leave($data,$id);
            if($response==true){
                if($data['leave_status']==1)
                {
                    
                    // $jd=gregoriantojd($data['leave_date_from']);
                    // echo jddayofweek($jd,1);die;
                    if($data['leave_type']=='medical')
                    {
                        //  $holiday=$this->leave_model->get_all_holiday();\
                        //  $current_holiday=$holiday[0]->

                        
                       

                         
                        // $day_from = date('l', $timestamp);
                        // var_dump($day);
                        // $timestamp = date('Y-m-d', strtotime('-1 day', strtotime('leave_date_from'))) ;
                        // $day_before=date('l', $timestamp); 

                       
                        
                    //     $timestamp = strtotime($data['leave_date_to']);
                    //   echo   $day_to = date('l', $timestamp); die;
                        
                        // $timestamp = strtotime('friday last week');
                        // $day_to_lastweek = date('l', $timestamp);
                        
                        
                        $current=$this->leave_model->get_leaves($leave_date_to,$user_id);
                        $current = strtotime($data['leave_date_to']);
                        $day_to_currrent = date('l', $current); 
                        

                       
                        
                      if($day_to_currrent=='Monday')
                      {
                        $previous_leave['prev_leave'] = $this->leave_model->previous_leave($data['leave_date_to'],$user_id);
                            //echo '<pre>';print_r($data['prev_leave']);die;
                         
                        $previous_day_of_leave =$previous_leave['leave_date_to'];

                        $previous_day_of_leave = strtotime($data['leave_date_to']);
                        $day_to_previous = date('l', $previous_day_of_leave);  
                        if(day_to_previous=='Friday')
                        {

                            
                            $diff= ($current - $previous_day_of_leave);
                            $day= abs(round($diff / 86400)) + 3; 
                            $this->leave_model->update_day($day_data,$user_id,$data['leave_type']);
                        }

                        }

                        else
                        {
                          
                       $diff= strtotime($data['leave_date_from'])-strtotime($data['leave_date_to'] );
                       $day= abs(round($diff / 86400)) +1;
                        }
                      

                      
                      {

                      
                    $diff= strtotime($data['leave_date_from'])-strtotime($data['leave_date_to']);
                      }
                    $day= abs(round($diff / 86400)) + 1;
                    $curent_day_count_for_medical = $this->leave_model->get_curent_leave($data['leave_type'],$user_id);
                     $medical_leave=$curent_day_count_for_medical[0]->leave_count; 
                    $now_date_count =  $medical_leave-$day;
                    $day_data = array('leave_count'=>$now_date_count);
                    $this->leave_model->update_day($day_data,$user_id,$data['leave_type']);
                    }
                     else {
                    $diff= strtotime($data['leave_date_from'])-strtotime($data['leave_date_to']) ;
                    $day= abs(round($diff / 86400)) + 1;
                    $curent_day_count_for_casual = $this->leave_model->get_curent_leave($data['leave_type'],$user_id);
                    $casual_leave=$curent_day_count_for_casual[0]->leave_count;
                    $now_date_count =  $casual_leave-$day;
                    $day_data = array('leave_count'=>$now_date_count);
                    $this->leave_model->update_day($day_data,$user_id,$data['leave_type']);
                    }
                }
                $messge = array('message' => 'leave updated  successfull.','class' => 'alert alert-success fade in');  
                $this->session->set_flashdata('leave', $messge);
                redirect('/user/leave');
            }
            else{
                $messge = array('message' => 'Something went wrong...!!!','class' => 'alert alert-danger fade in');  
                $this->session->set_flashdata('leave', $messge);
                redirect('/user/leave');
            }
        }
        public function remove_leave(){
            $leave_id = $this->uri->segment(4);
            $rec = $this->leave_model->remove_leave($leave_id);
            $messge = array('message' => 'leave successfully deleted','class' => 'alert alert-danger fade in');  
               $this->session->set_flashdata('leave', $messge);
           return $rec;
       }    

}