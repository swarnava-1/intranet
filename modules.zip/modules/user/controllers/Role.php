<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @author: Swarnava Banerjee
 * FileName: User.php
 * Function: Controller for manging users login
 * Created: 21/03/2022
 *
 *
 * Dependencies:
 *
 * Modified on: 21/03/2022
 * Modified by:Swarnava Banerjee
 *
 * Scripting language: PHP5
 * Tested on: PHP version  7.2.25, Apache 2, Windows.
 *
 */

class Role extends MY_Controller {

	function __construct()
	{		
		parent::__construct();

		$this->load->module('layout');	
		$this->load->model('role_model');
	}

	public function index()
	{ 
        //echo $this->session->userdata('id');die; 
        $data['roles']= $this->role_model->get_all_roles();
		$this->layout->load($data)->render();
	}
    public function add(){
		$this->layout->load($data)->render();
    }
   
        
    public function insert_role() {  
        if($this->input->post())
            {
                $data['role_name']=$this->input->post('role_name');
                $data['status']=$this->input->post('is_active');
                
                $response=$this->role_model->add_roles($data);
                if($response==true){
                    $messge = array('message' => 'Role inserted successfull.','class' => 'alert alert-success fade in');  
                    $this->session->set_flashdata('role', $messge);
                    redirect('/user/role');

                }
                else{
                    $messge = array('message' => 'Something went wrong...!!!','class' => 'alert alert-danger fade in');  
                    $this->session->set_flashdata('role', $messge);
                    redirect('/user/role');

                }
            }          
        }   
    public function edit() {  
        $id = $this->uri->segment(4);
        $data['role_details']=$this->role_model->get_role_by_id($id);
        //echo '<pre>';print_r($data['role_details']);die;
        $this->layout->load($data)->render();         
    }

    public function update_role(){
        $id = $this->input->post('role_id');
        $data['role_name']=$this->input->post('role_name');
        $data['status']=$this->input->post('is_active');
        //echo '<pre>';print_r($data);die;
        $response=$this->role_model->update_roles($data,$id);
        if($response==true){
            $messge = array('message' => 'Role updated  successfull.','class' => 'alert alert-success fade in');  
            $this->session->set_flashdata('role', $messge);
            redirect('/user/role');
        }
        else{
            $messge = array('message' => 'Something went wrong...!!!','class' => 'alert alert-danger fade in');  
            $this->session->set_flashdata('role', $messge);
            redirect('/user/role');
        }
    } 
    public function remove_role(){
        $role_id = $this->uri->segment(4);
        $rec = $this->role_model->remove_role($role_id);
        $messge = array('message' => 'Role successfully deleted','class' => 'alert alert-danger fade in');  
            $this->session->set_flashdata('role', $messge);
        return $rec;

    }
}


