<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @author: Swarnava Banerjee
 * FileName: User.php
 * Function: Controller for manging users login
 * Created: 21/03/2022
 *
 *
 * Dependencies:
 *
 * Modified on: 21/03/2022
 * Modified by:Swarnava Banerjee
 *
 * Scripting language: PHP5
 * Tested on: PHP version  7.2.25, Apache 2, Windows.
 *
 */

class Designation extends MY_Controller {

	function __construct()
	{		
		parent::__construct();

		$this->load->module('layout');	
		$this->load->model('designation_model');
	}

	public function index()
	{
        $data['designation']= $this->designation_model->get_all_designation();
		$this->layout->load($data)->render();
	}
    public function add(){
        
		$this->layout->load($data)->render();
    }
    public function insert_designation() {  
        if($this->input->post())
            {
                $data['designation_name']=$this->input->post('designation_name');
                $data['status']=$this->input->post('is_active');
                
                $response=$this->designation_model->add_designation($data);
                if($response==true){
                    $messge = array('message' => 'Role inserted successfull.','class' => 'alert alert-success fade in');  
                    $this->session->set_flashdata('designation', $messge);
                    redirect('/user/designation');

                }
                else{
                    $messge = array('message' => 'Something went wrong...!!!','class' => 'alert alert-danger fade in');  
                    $this->session->set_flashdata('designation', $messge);
                    redirect('/user/designation');

                }
            }          
        }
        public function edit() {  
            $id = $this->uri->segment(4);
            $data['desig_details']=$this->designation_model->get_designation_by_id($id);
            //echo '<pre>';print_r($data['role_details']);die;
            $this->layout->load($data)->render();         
        }
    
        public function update_designation(){
            $id = $this->input->post('designation_id');
            $data['designation_name']=$this->input->post('designation_name');
            $data['status']=$this->input->post('is_active');
            //echo '<pre>';print_r($data);die;
            $response=$this->designation_model->update_designation($data,$id);
            if($response==true){
                $messge = array('message' => 'designation updated  successfull.','class' => 'alert alert-success fade in');  
                $this->session->set_flashdata('designation', $messge);
                redirect('/user/designation');
            }
            else{
                $messge = array('message' => 'Something went wrong...!!!','class' => 'alert alert-danger fade in');  
                $this->session->set_flashdata('designation', $messge);
                redirect('/user/designation');
            }
        }
        public function remove_designation(){
             $designation_id = $this->uri->segment(4);
             $rec = $this->designation_model->remove_designation($designation_id);
             $messge = array('message' => 'designation successfully deleted','class' => 'alert alert-danger fade in');  
                $this->session->set_flashdata('designation', $messge);
            return $rec;
        }    
        

}