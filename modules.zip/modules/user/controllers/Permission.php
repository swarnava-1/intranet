<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @author: Swarnava Banerjee
 * FileName: User.php
 * Function: Controller for manging users login
 * Created: 21/03/2022
 *
 *
 * Dependencies:
 *
 * Modified on: 21/03/2022
 * Modified by:Swarnava Banerjee
 *
 * Scripting language: PHP5
 * Tested on: PHP version  7.2.25, Apache 2, Windows.
 *
 */

class Permission extends MY_Controller {

	function __construct()
	{		
		parent::__construct();

		$this->load->module('layout');	
		$this->load->model('permission_model');
        $this->load->model('page_model');
	}

	public function index()
	{
        $data['permission']= $this->permission_model->get_all_permissions();
		$this->layout->load($data)->render();
	}
    public function add(){
        $data['pages']= $this->page_model->get_all_pages();
		$this->layout->load($data)->render();
    }
    public function insert_permission() {
       
        if($this->input->post())
            {
                $data['menu_name']=$this->input->post('menu_name');
                $data['submenu']=$this->input->post('submenu');
                $data['page_name']=$this->input->post('page_name');
                $data['link_page']=$this->input->post('link_page');
                $data['order_no']=$this->input->post('order_no');
                $data['action']=$this->input->post('action');
                $data['description']=$this->input->post('description');
                $data['created_by']=$this->session->userdata('id');
                $data['updated_by']=$this->session->userdata('id');
                //echo '<pre>';print_r($data);die;
                $response=$this->permission_model->insert_permission($data);
                if($response==true){
                    $messge = array('message' => 'permission inserted successfull.','class' => 'alert alert-success fade in');  
                    $this->session->set_flashdata('permission', $messge);
                    redirect('/user/permission');

                }
                else{
                    $messge = array('message' => 'Something went wrong...!!!','class' => 'alert alert-danger fade in');  
                    $this->session->set_flashdata('permission', $messge);
                    redirect('/user/permission');
                    
                }
            }          
        }
        public function edit() {  
            $id = $this->uri->segment(4);
            $data['pages']= $this->page_model->get_all_pages();
            $data['permission_details']=$this->permission_model->get_permission_by_id($id);
            //echo '<pre>';print_r($data['permission_details']);die;
            $this->layout->load($data)->render();         
        }
    
        public function update_permission(){
            $id = $this->input->post('permission_id');
            $data['menu_name']=$this->input->post('menu_name');
            $data['submenu']=$this->input->post('submenu');
            $data['page_name']=$this->input->post('page_name');
            $data['link_page']=$this->input->post('link_page');
            $data['order_no']=$this->input->post('order_no');
            $data['action']=$this->input->post('action');
            $data['description']=$this->input->post('description');
            $data['created_by']=$this->session->userdata('id');
            $data['updated_by']=$this->session->userdata('id');
            //echo '<pre>';print_r($data);die;
            $response=$this->permission_model->update_permission($data,$id);
            if($response==true){
                $messge = array('message' => 'permission updated  successfull.','class' => 'alert alert-success fade in');  
                $this->session->set_flashdata('permission', $messge);
                redirect('/user/permission');
            }
            else{
                $messge = array('message' => 'Something went wrong...!!!','class' => 'alert alert-danger fade in');  
                $this->session->set_flashdata('permission', $messge);
                redirect('/user/permission');
            }
        }
        public function remove_permission(){
            $permission->id = $this->uri->segment(4);
            $rec = $this->permission_model->remove_permission($permission->id);
            $messge = array('message' => 'permission successfully deleted','class' => 'alert alert-danger fade in');  
            $this->session->set_flashdata('permission', $messge);
            return $rec;    
        }        

}