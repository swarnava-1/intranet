<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @author: Swarnava Banerjee
 * FileName: User.php
 * Function: Controller for manging users login
 * Created: 21/03/2022
 *
 *
 * Dependencies:
 *
 * Modified on: 21/03/2022
 * Modified by:Swarnava Banerjee
 *
 * Scripting language: PHP5
 * Tested on: PHP version  7.2.25, Apache 2, Windows.
 *
 */

class Rolepermission extends MY_Controller {

	function __construct()
	{		
		parent::__construct();

		$this->load->module('layout');	
		$this->load->model('rolepermission_model');
		$this->load->model('role_model');
		$this->load->model('permission_model');
        //$this->load->model('page_model');
	}

	public function index()
	{
		$data['roles']=$this->role_model->get_all_roles();
		$data['permission']= $this->permission_model->get_all_permissions();
        $data['rolepermission']= $this->rolepermission_model->get_all_role_permission();
		$this->layout->load($data)->render();
	}
    public function add(){
		$data['roles']=$this->role_model->get_all_roles();
		$this->layout->load($data)->render();
    }
	public function insert_rolepermission() {
       
        if($this->input->post())
            {
                $data['role_id']=$this->input->post('role_id');
                $data['permission_id']=$this->input->post('permission_id');
                //echo '<pre>';print_r($data);die;
                $response=$this->rolepermission_model->add_rolespermission($data);
                if($response==true){
                    $messge = array('message' => 'permission inserted successfull.','class' => 'alert alert-success fade in');  
                    $this->session->set_flashdata('permission', $messge);
                    redirect('/user/permission');

                }
                else{
                    $messge = array('message' => 'Something went wrong...!!!','class' => 'alert alert-danger fade in');  
                    $this->session->set_flashdata('permission', $messge);
                    redirect('/user/permission');
                    
                }
            }          
        }
}