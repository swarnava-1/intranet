<?php
class Leave_model extends CI_Model {
 
    /**
    * Responsable for auto load the database
    * @return void
    */
    public function __construct() {

        $this->load->database();
    }
  	
    public function get_all_leave() {

    	$this->db->select('*');
    	$this->db->from('leave');
		$query = $this->db->get();
		return $query->result();
    
    }
    public function add_leave($data){
       
        $query = $this->db->insert('leave',$data);
        return $query;

    } 
    public function get_leave_by_id($id){
        $this->db->select('*');
        $this->db->from('leave');
        $this->db->where('id',$id);
        $query=$this->db->get();  
        return $query->result();
    }
    public function update_leave($data,$id)
    {
        $this->db->where('id', $id);
    	$flag =$this->db->update('leave', $data);
        return $flag;
    }
    public function remove_leave($leave_id){        
        $this->db->where('id', $leave_id);
        $rec = $this->db->delete('leave');
        return $rec;
    }
    
    
    public function get_all_total_leave($user_id) {

    	$this->db->select('leave_count,leave_type');
    	$this->db->from('total_leave');
		$this->db->where('user_id',$user_id);
        $query=$this->db->get();
        return $query->result();

    
    }
    public function get_all_users($user_id) {

        $this->db->select('user.id,user_name,CONCAT(first_name," ",last_name) AS full_name,email,designation_name');
        $this->db->from('user');
        $this->db->join('designation','user.designation=designation.id');
        $this->db->where('user.id !=' , $user_id);
        $query=$this->db->get();
        return $query->result();
    
    }
    public function get_curent_leave($leave_type,$user_id)
    {
       $this->db->select('leave_count');
       $this->db->from('total_leave');
       $this->db->where('leave_type',$leave_type);
       $this->db->where('user_id',$user_id);
       $query=$this->db->get();
       return $query->result();
    }
    public function update_day($now_date,$user_id,$leave_type){
        $this->db->where('leave_type',$leave_type);
        $this->db->where('user_id',$user_id);
        $flag =$this->db->update('total_leave', $now_date);
        return $flag;
    }

    // public function get_all_total_leave($user_id) {

    // 	$this->db->select('leave_count,leave_type,');
    // 	$this->db->from('total_leave');
    //     $this->db->join('leave')
	// 	$this->db->where('user_id',$user_id);
    //     $this->db->

    //     $query=$this->db->get();
    //     return $query->result();

    
    // }

}