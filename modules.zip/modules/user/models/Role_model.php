<?php
class Role_model extends CI_Model {
 
    /**
    * Responsable for auto load the database
    * @return void
    */
    public function __construct() {

        $this->load->database();
    }
  	
    public function get_all_roles() {

    	$this->db->select('*');
    	$this->db->from('role');
        $this->db->where('status','1');
		$query = $this->db->get();
		return $query->result();
    
    }
    public function add_roles($data){
       
        $query = $this->db->insert('role',$data);
        return $query;

    }
    public function get_role_by_id($id){
           $this->db->select('*');
           $this->db->from('role');
           $this->db->where('id',$id);
           $query=$this->db->get();
           return $query->result();
    }   
    public function update_roles($data,$id)
    {
        $this->db->where('id', $id);
    	$flag =$this->db->update('role', $data);
        return $flag;
    }

    public function remove_role($role_id){
        
        $this->db->where('id', $role_id);
        $rec = $this->db->delete('role');
        return $rec;

    }
    
    
    
	
}