<?php
class Permission_model extends CI_Model {
 
    /**
    * Responsable for auto load the database
    * @return void
    */
    public function __construct() {

        $this->load->database();
    }
    public function get_all_permissions() {

        $this->db->select('permission.id,description,action,menu_name,submenu,order_no,location');
        $this->db->from('permission');
        $this->db->join('page','permission.page_name=page.id');
        $query=$this->db->get();
        return $query->result();
        
        }
    // public function get_all_permissions() {

    // 	$this->db->select('*');
    // 	$this->db->from('permission');
	// 	$query = $this->db->get();
	// 	return $query->result();
    
    // }
    public function insert_permission($data){
       
        $query = $this->db->insert('permission',$data);
        return $query;

    } 
    public function get_permission_by_id($id){
        $this->db->select('*');
        $this->db->from('permission');
        $this->db->where('id',$id);
        $query=$this->db->get();  
        return $query->result();
    }   
    public function update_permission($data,$id)
    {
        $this->db->where('id', $id);
    	$flag =$this->db->update('permission', $data);
        return $flag;
    }
    public function remove_permission($permission_id){
        
        $this->db->where('id', $permission_id);
        $rec = $this->db->delete('permission');
        return $rec;

    }
    
}