<?php
class 
Designation_model extends CI_Model {
 
    /**
    * Responsable for auto load the database
    * @return void
    */
    public function __construct() {

        $this->load->database();
    }
  	
    public function get_all_designation() {

    	$this->db->select('*');
    	$this->db->from('designation');
		$query = $this->db->get();
		return $query->result();
    
    }
    public function add_designation($data){
       
        $query = $this->db->insert('designation',$data);
        return $query;

    }
    public function get_designation_by_id($id){
        $this->db->select('*');
        $this->db->from('designation');
        $this->db->where('id',$id);
        $query=$this->db->get();
        return $query->result();
    }   
    public function update_designation($data,$id)
    {
     $this->db->where('id', $id);
     $flag =$this->db->update('designation', $data);
     return $flag;
    }

    public function remove_designation($designation_id){        
        $this->db->where('id', $designation_id);
        $rec = $this->db->delete('designation');
        return $rec;
    }


}

 