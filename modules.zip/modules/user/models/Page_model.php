<?php
class Page_model extends CI_Model {
 
    /**
    * Responsable for auto load the database
    * @return void
    */
    public function __construct() {

        $this->load->database();
    }
  	
    public function get_all_pages() {

    	$this->db->select('*');
    	$this->db->from('page');
		$query = $this->db->get();
		return $query->result();
    
    }
    public function add_pages($data){
       
        $query = $this->db->insert('page',$data);
        return $query;

    } 
    public function get_page_by_id($id){
        $this->db->select('*');
        $this->db->from('page');
        $this->db->where('id',$id);
        $query=$this->db->get();  
        return $query->result();
    }   
    public function update_page($data,$id)
    {
        $this->db->where('id', $id);
    	$flag =$this->db->update('page', $data);
        return $flag;
    }

    public function remove_page($page_id){
        
        $this->db->where('id', $page_id);
        $rec = $this->db->delete('page');
        return $rec;

    }
}