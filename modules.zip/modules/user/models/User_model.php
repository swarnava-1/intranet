<?php
class User_model extends CI_Model {
 
    /**
    * Responsable for auto load the database
    * @return void
    */
    public function __construct() {

        $this->load->database();
    }
  	
    public function check_login($uname, $pass) {

    	$this->db->select('*');
    	$this->db->from('user');
    	$this->db->where('user_name', $uname);
    	$this->db->where('password', $pass);
		$query = $this->db->get();
		return $query->result();
    
    }
    public function get_all_users() {

        $this->db->select('user.id,user_name,CONCAT(first_name," ",last_name) AS full_name,email,designation_name');
        $this->db->from('user');
        $this->db->join('designation','user.designation=designation.id');
        $query=$this->db->get();
        return $query->result();
    
    }
    public function add_users($data){
       
        $query = $this->db->insert('user',$data);
        return $query;

    }
    public function get_user_by_id($id){
        $this->db->select('*');
        $this->db->from('user');
        $this->db->where('id',$id);
        $query=$this->db->get();
        return $query->result();
 }   
    public function update_users($data,$id)
    {
     $this->db->where('id', $id);
     $flag =$this->db->update('user', $data);
     return $flag;
    }
    public function remove_user($user_id){
        
        $this->db->where('id', $user_id);
        $rec = $this->db->delete('user');
        return $rec;

    }
    public function joining_tables()
    {
        $this->db->select('user_name,user_name,email,designation_name');
        $this->db->from('user');
        $this->db->join('designation','user.designation=designation.id');
        $query=$this->db->get();
    }


	
}