<?php
class Rolepermission_model extends CI_Model {
 
    /**
    * Responsable for auto load the database
    * @return void
    */
    public function __construct() {

        $this->load->database();
    }
  	
    // public function get_all_role_permission() {

    // 	$this->db->select('*');
    // 	$this->db->from('role_permission');
	// 	$query = $this->db->get();
	// 	return $query->result();
    
    // }
    public function get_all_role_permission() {

        $this->db->select('role_permission.id,role.role_name,permission.description');
        $this->db->from('role_permission');
        $this->db->join('role','role_permission.id=role.role_name');
        $this->db->join('permission','role_permission.id=permission.description');
        $query=$this->db->get();
        return $query->result();
        
        }
    public function add_rolespermission($data){
       
        $query = $this->db->insert('role_permission',$data);
        return $query;

    }
}