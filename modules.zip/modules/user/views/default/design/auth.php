<!-- Notification -->
<p><?php echo validation_errors('<div class="alert alert-danger">','</div>'); ?>&nbsp;
         <?php echo $message; $message="";?>  </p>
		<!-- /Notification -->
<!--Show Flash Messages Success/Error Message-->
<?php 
  if($this->session->flashdata('success_msg'))
  {
  ?>
  <div class="alert alert-success">
    <strong>Success!</strong> <?php echo $this->session->flashdata('success_msg');?>
  </div>
  <?php
  }

  ?>

<?php 
  if($this->session->flashdata('error_msg'))
  {
?>
 <div class="alert alert-danger">
    <strong>Error!</strong> <?php echo $this->session->flashdata('error_msg');?>
  </div>
<?php
  }
 ?>
<form class="user" action="<?php echo site_url('/user/auth');?>" method="post">
<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">     

    <div class="form-group">
      <input type="text" class="form-control" name="uname" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Enter User Name..." value="<?php echo $this->input->cookie('uname');?>">
    </div>
    <div class="form-group">
      <input type="password" class="form-control" name="password" id="exampleInputPassword" placeholder="Password" value="<?php echo $this->input->cookie('password');?>">
    </div>
    <div class="form-group">
      <div class="custom-control custom-checkbox small">
          <input type="checkbox" class="custom-control-input remember" name="customCheck" id="customCheck">
          <label class="custom-control-label" for="customCheck">Remember Me</label>
      </div>
    </div>
    <button type="submit" class="btn btn-primary btn-user btn-block">Login</button>
  <hr>
</form>
