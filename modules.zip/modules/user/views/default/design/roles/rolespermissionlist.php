

<!-- Page Heading -->
<div class="clearfix card-header">
    <div class="float-right">
      <a href="<?php echo base_url('/user/roles_permission/add_permission/')?>" class="btn btn-primary btn-circle">
        <i class="fas fa-plus" data-toggle="tooltip" data-placement="bottom" title="Add Role Permission"></i>
      </a>
    </div>
    <div class="float-left">
      <h1 class="h3 mb-2 text-gray-800 ">Roles Management</h1>
    </div><br>
    
</div>

<!--Show Flash Messages Success/Error Message-->
<?php 
  if($this->session->flashdata('success_msg'))
  {
  ?>
  <div class="alert alert-success">
    <strong>Success!</strong> <?php echo $this->session->flashdata('success_msg');?>
  </div>
  <?php
  }

  ?>

<?php 
  if($this->session->flashdata('error_msg'))
  {
?>
 <div class="alert alert-danger">
    <strong>Error!</strong> <?php echo $this->session->flashdata('error_msg');?>
  </div>
<?php
  }
  
  ?>

<!-- Menu List-->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <div class="clearfix card-header">
      <div class="float-left">
      <h6 class="m-0 font-weight-bold text-primary">Roles Permission List</h6>
      </div>
      <!-- <div class="float-right">
        <select name="menu_type_search" id="menu_type_search" class="form-control" onchange="getmenu(this.value,'dataTable tbody','table')">
          <option value="BM">Backend Menu</option>
          <option value="FM">Frontend Menu</option>
        </select>
      </div>       -->
    </div>

  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered text-gray-900" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>Roles Name</th>
            <th>Permissions</th>
            <th>Action</th>
          </tr>
        </thead>
        <tfoot>
          <tr>
          <th>Roles Name</th>
          <th>Permissions</th>
          <th>Action</th>
          </tr>
        </tfoot>
        <tbody>
          <?php foreach($data['rolespermission'] as $rolepermissions){?>
          <tr>
            <td><?php echo $rolepermissions->role_name?></td>
            <td><?php echo $rolepermissions->permissions?></td>
            <td><a href="<?php echo base_url();?>user/roles_permission/edit_permission/<?php echo $rolepermissions->roleid?>"><i class="far fa-edit"></i></a><a href="javascript:void(0)" onclick="remove_element('<?php echo $rolepermissions->roleid;?>','rolespermission')"><i class="far fa-trash-alt"></i></a></td>
          </tr>  
          <?php } ?> 
        </tbody>
      </table>
    </div>
  </div>
</div>



