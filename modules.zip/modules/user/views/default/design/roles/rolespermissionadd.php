<div class="row text-gray-900">
        <div class="col-lg-12">
            <div class="card shadow">
                <div class="clearfix card-header">
                    <div class="float-right">
                        <a href="<?php echo base_url('/user/roles_permission/')?>" class="btn btn-primary btn-circle pull-right">
                        <i class="fas fa-backward" data-toggle="tooltip" data-placement="bottom" title="Back to Role Permission Listing page"></i>
                        </a>
                    </div>
                    <div class="float-left">
                     <h6 class="m-0 font-weight-bold text-primary">Roles Permission</h6>
                    </div>                                      
                </div>


                <div class="card-body">                
                <form class="needs-validation" novalidate action="<?php echo site_url('user/roles_permission/addrolepermission/'.$data['id']);?>" method="POST">
                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">           
                    <div class="form-group row">
                        <div class="col-sm-6">
                        <label>Roles Name</label>
                        <select class="form-control" name="role_id" required>        
                            <option value="">Select Role</option>
                            <?php foreach($data['roles'] as $row) { ?>
                            <option value="<?=$row->id?>"><?=$row->role_name?></option>
                            <?php } ?>
                        </select>
                        </div>
                    </div>
                    <div class="form-group row">                      
                        <div class="col-sm-6">
                            <label>Available Permissions</label>  <br>                             
                            <select multiple="multiple" size="10" class="dualbox" name="duallistbox[]" required> 
                                <?php foreach($data['permissions'] as $row) { ?>
                                <option value="<?=$row->id?>"><?=$row->permisson_name?></option>
                                <?php } ?>
                            </select>                             
                        </div>   
                    </div>                  
                    </div>
                    <div class="form-group row">
                        
                        <div class="col-sm-3">
                            <input type="submit" class="btn btn-primary btn-user btn-block" value="Submit">
                        </div>
                        <div class="col-sm-3">
                            <input type="reset" class="btn btn-user btn-block btn-secondary" value="Reset">
                        </div>                        
                    </div>                    
                </form>
                </div>
            </div>
        </div>    
    </div>
         

