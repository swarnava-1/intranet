<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="card shadow ">
                <div class="card-header py-3"><h6 class="m-0 font-weight-bold text-primary">Menu Management</h6></div>
                <div class="card-body">
                <?php //echo form_open( base_url('cms/altermenu/'.$data['id'] ), array( 'id' => 'menu-form', 'class' => 'needs-validation' ) );?>
                <form class="needs-validation" novalidate action="<?php echo base_url();?>cms/altermenu/<?php echo $data['id'];?>" method="POST">
                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">           
                    <div class="form-group row">
                        <div class="col-sm-6">
                        <label>Menu Type</label>
                        <select class="form-control" required name="menu_type">
                                <option value="">Select Menu Type</option>
                                <option value="BM">Backend Menu</option>
                                <option value="FM">Frontend Menu</option>  
                        </select>
                        </div>
                        
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-6">
                        <label>Menu Name</label>
                        <input type="text" class="form-control string_title" name="menu_name" placeholder="Menu Name" required>
                        </div>                        
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-6">
                        <label>Menu URL</label>
                        <input type="text" class="form-control string_base_name" name="menu_url" placeholder="Menu URL">
                        </div>                        
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6">
                        <label>Parent Menu</label>
                        <select class="form-control" required name="parent_id">
                                <option value="">Select Parent Menu</option>
                                <option value='0'>Top Level</option>           
                        </select>
                        </div>
                        
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6">
                        <label> Display Sequence</label>
                        <input type="number" class="form-control" name="display_sequence" placeholder="Display Sequence" required onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))">
                        </div>
                        
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-6">
                        <label>Level</label> 
                        <input type="number" class="form-control" name="level" placeholder="Menu Level" required onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))">
                        </div>
                        
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-6">
                        <label>Display Menu at</label>
                        <select class="form-control" required name="display_location"> 
                                <option value="">Menu Location</option>
                                <option value="HM">Header</option>
                                <option value="FM">Footer</option>     
                                <option value="NO">Do not display menu</option>                
                        </select>
                        </div>
                        
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3">
                            <input type="submit" class="btn btn-primary btn-user btn-block" value="Submit">
                        </div>
                        <div class="col-sm-3">
                            <input type="reset" class="btn btn-user btn-block btn-secondary" value="Reset">
                        </div>
                        
                    </div>
                    
                </form>
                </div>
            </div>
        </div>    
    </div>
         
</div>








