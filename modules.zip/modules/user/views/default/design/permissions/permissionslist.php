<script type="application/javascript">
/** After windod Load */
$(window).bind("load", function() {
  window.setTimeout(function() {
    $(".alert").fadeTo(500, 0).slideUp(500, function(){
        $(this).remove();
    });
}, 4000);
});
</script>
<style>
  .opecity{
    opacity:1!important;
  }
</style>
<!-- Page Heading -->
<div class="clearfix card-header">
    <div class="float-right">
      <a href="<?php echo base_url('/user/permission/add/')?>" class="btn btn-primary btn-circle">
        <i class="fas fa-plus" data-toggle="tooltip" data-placement="bottom" title="Add Permission"></i>
      </a>
    </div>
    <div class="float-left">
      <h1 class="h3 mb-2 text-gray-800 ">Permission Management</h1>
    </div><br>
</div>



<!--Show Flash Messages Success/Error Message-->
<?php

if($this->session->flashdata('permission')) {
$message = $this->session->flashdata('permission');
?>
<div class="<?php echo $message['class']?> opecity"><?php echo $message['message']; ?>

</div>
<?php
}
?>

<!-- Menu List-->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <div class="clearfix card-header">
      <div class="float-left">
      <h6 class="m-0 font-weight-bold text-primary">Permission List</h6>
      </div>
      <!-- <div class="float-right">
        <select name="menu_type_search" id="menu_type_search" class="form-control" onchange="getmenu(this.value,'dataTable tbody','table')">
          <option value="BM">Backend Menu</option>
          <option value="FM">Frontend Menu</option>
        </select>
      </div>       -->
    </div>

  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered text-gray-900" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>Permission Description</th>
            <th>Action</th>
            <th>Menu</th>
            <th>Submenu</th>
            <th>Order no </th>
            <th>Page </th>
            <th>Action</th>
          </tr>
        </thead>
        <tfoot>
          <tr>
            
            <th>Permission Description</th>
            <th>Action</th>
            <th>Menu</th>
            <th>Submenu</th>
            <th>Order no </th>
            <th>Page </th>
            <th>Action</th>
          </tr>
        </tfoot>
        <tbody>
          <?php foreach($data['permission'] as $permission){?>
          <tr>
            <td><?php echo $permission->description?></td>
            <td><?php echo $permission->action?></td>
            <td><?php echo $permission->menu_name?></td>
            <td><?php echo $permission->submenu?></td>
            <td><?php echo $permission->order_no?></td>
            <td><?php echo $permission->location?></td>
            <td>
            <a href="<?php echo base_url();?>user/permission/edit/<?php echo $permission->id?>"><i class="far fa-edit"></i></a> 
              <a href="javascript:void(0)" onclick="remove_element('<?php echo $permission->id;?>','permission')"><i class="far fa-trash-alt"></i></a>
            </td>
          </tr>  
          <?php } ?> 
        </tbody>
      </table>
    </div>
  </div>
</div>



