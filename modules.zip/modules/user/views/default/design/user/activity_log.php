

<!-- Page Heading -->
<div class="clearfix card-header">
    <div class="float-right">
      
    </div>
    <div class="float-left">
      <h1 class="h3 mb-2 text-gray-800 ">User Log Activity</h1>
    </div><br>
    
</div>


<!-- Log List-->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <div class="clearfix card-header">
      <div class="float-left">
      <h6 class="m-0 font-weight-bold text-primary">Log List</h6>
      </div>
    </div>

  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered text-gray-900" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>Log Message</th>
            <th>Log Date/Time</th>
            <th>Host Ip</th>
            <th>Target Page</th>
          </tr>
        </thead>
        <tfoot>
          <tr>
            <th>Log Message</th>
            <th>Log Date/Time</th>
            <th>Host Ip</th>
            <th>Target Page</th>
          </tr>
        </tfoot>
        <tbody>
          <?php 
          if(!empty($data['useractivity']['data']))
          {
          foreach($data['useractivity']['data'] as $row){?>
          <tr>
            <td><?php echo $row['log_msg'];?></td>
            <td><?php echo $row['created_at'];?></td>
            <td><?php echo $row['host_ip'];?></td>
            <td><?php echo $row['http_referer'];?></td>
          </tr>  
          <?php } 
          }?>
        </tbody>
      </table>
    </div>
  </div>
</div>



