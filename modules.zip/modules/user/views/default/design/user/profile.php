<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="card shadow ">
                <div class="card-header py-3"><h6 class="m-0 font-weight-bold text-primary">Manage Profile</h6></div>
                <!--Show Flash Messages Success/Error Message-->
                    <?php 
                    if($this->session->flashdata('success_msg'))
                    {
                    ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong> <?php echo $this->session->flashdata('success_msg');?>
                    </div>
                    <?php
                    }

                    ?>

                    <?php 
                    if($this->session->flashdata('error_msg'))
                    {
                    ?>
                    <div class="alert alert-danger">
                        <strong>Error!</strong> <?php echo $this->session->flashdata('error_msg');?>
                    </div>
                    <?php
                    }
                    
                    ?>
                <div class="card-body">
                <form class="needs-validation" novalidate action="<?php echo base_url();?>user/profile/alterprofile" method="POST">
                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">

                    <div class="form-group row">
                        <div class="col-sm-6">
                        <label>First Name</label><label style="color:red;">*</label>
                        <input type="text" class="form-control" name="first_name" placeholder="First Name" required value="<?php echo (isset($data['profile_details']['first_name'])) ?$data['profile_details']['first_name']:"";?>">
                        </div>                        
                    </div>
                    <input type="hidden" value="<?php echo $this->session->userdata('user_id');?>" name ="user_id">
                    <div class="form-group row">
                        <div class="col-sm-6">
                        <label>Last Name</label><label style="color:red;">*</label>
                        <input type="text" class="form-control" name="last_name" placeholder="Last Name" required value="<?php echo (isset($data['profile_details']['last_name'])) ?$data['profile_details']['last_name']:"";?>">
                        </div>                        
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6">
                        <label>Email</label><label style="color:red;">*</label>
                        <input type="email" class="form-control" name="emailId" placeholder="Email" required value="<?php echo (isset($data['profile_details']['emailId'])) ?$data['profile_details']['emailId']:"";?>">
                        </div>                        
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6">
                        <label>Phone</label><label style="color:red;">*</label>
                        <input type="text" class="form-control" name="phnumber" placeholder="Phone" required value="<?php echo (isset($data['profile_details']['phnumber'])) ?$data['profile_details']['phnumber']:"";?>">
                        </div>                        
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-3">
                            <input type="submit" class="btn btn-primary btn-user btn-block" value="Submit">
                        </div>
                        <div class="col-sm-3">
                            <input type="reset" class="btn btn-user btn-block btn-secondary" value="Reset">
                        </div>
                        
                    </div>
                    
                </form>
                </div>
            </div>
        </div>    
    </div>
         
</div>








