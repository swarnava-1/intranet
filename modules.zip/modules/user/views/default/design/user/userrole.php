<div class="row text-gray-900">
        <div class="col-lg-12">
            <div class="card shadow">
                <div class="clearfix card-header">
                    <div class="float-right">
                        <a href="<?php echo base_url('/user/index')?>" class="btn btn-primary btn-circle pull-right">
                        <i class="fas fa-backward"></i>
                        </a>
                    </div>
                    <div class="float-left">
                     <h6 class="m-0 font-weight-bold text-primary">Assign Role to User</h6>
                    </div>                                      
                </div>

                <div class="card-body">                
                <form class="needs-validation container" novalidate action="<?php echo site_url('user/updateuserrole/'.$data['id']);?>" method="POST">
                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">           
                    <div class="form-group row">
                        <div class="col-sm-6">
                        <label>User Id</label><label style="color:red">*</label>
                        <input type="text" class="form-control" required="" name="usrname" placeholder="User Name" required value="<?php echo $data['userrole'][0]['username'];?>" readonly>
                        <input type="hidden" name="user_id" value="<?php echo $data['userrole'][0]['userid']?>">
                    </div>
                    </div>
                    <div class="form-group row">                      
                        <div class="col-sm-6">
                            <label>Available Roles</label><label style="color:red">*</label> <br>                             
                            <select multiple="multiple" size="10" class="dualbox custom-select browser-default" name="duallistbox[]" required="required"> 
                                <?php foreach($data['roles'] as $row) { ?>
                                <option value="<?=$row->id?>,<?=$row->role_name?>" <?php foreach($data['userrole'] as $urole){ if($urole['role_id']==$row->id){echo 'selected=selected';}}?>><?=$row->role_name?></option>
                                <?php } ?>
                            </select>    
                            <div class="invalid-feedback">
                            <h5>Please choose Roles.</h5>
                            </div>                       
                        </div>  
                    </div>                  
                    </div>
                    <div class="form-group row">
                        
                        <div class="col-sm-3">
                            <input type="submit" class="btn btn-primary btn-user btn-block" value="Submit">
                        </div>
                        <div class="col-sm-3">
                            <input type="reset" class="btn btn-user btn-block btn-secondary" value="Reset">
                        </div>                        
                    </div>                    
                </form>
                </div>
            </div>
        </div>    
    </div>
         

