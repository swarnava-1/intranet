

<!-- Page Heading -->
<div class="clearfix card-header">
    <div class="float-right">
      
    </div>
    <div class="float-left">
      <h1 class="h3 mb-2 text-gray-800 ">User Log Management</h1>
    </div><br>
    
</div>

<!--Show Flash Messages Success/Error Message-->
<?php 
  if($this->session->flashdata('success_msg'))
  {
  ?>
  <div class="alert alert-success">
    <strong>Success!</strong> <?php echo $this->session->flashdata('success_msg');?>
  </div>
  <?php
  }

  ?>

<?php 
  if($this->session->flashdata('error_msg'))
  {
?>
 <div class="alert alert-danger">
    <strong>Error!</strong> <?php echo $this->session->flashdata('error_msg');?>
  </div>
<?php
  }
  
  ?>

<!-- Menu List-->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <div class="clearfix card-header">
      <div class="float-left">
      <h6 class="m-0 font-weight-bold text-primary">Log List</h6>
      </div>
    </div>

  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered text-gray-900" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>Log Message</th>
            <th>Log Date/Time</th>
            <th>Host Ip</th>
            <th>Target Page</th>
          </tr>
        </thead>
        <tfoot>
          <tr>
            <th>Log Message</th>
            <th>Log Date/Time</th>
            <th>Host Ip</th>
            <th>Target Page</th>
          </tr>
        </tfoot>
        <tbody>
          <?php foreach($data['user_logs'] as $ulist){?>
          <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>  
          <?php } ?> 
        </tbody>
      </table>
    </div>
  </div>
</div>



