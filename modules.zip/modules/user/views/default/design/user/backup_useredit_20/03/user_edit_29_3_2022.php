<div class="form-group row">
                        <div class="col-sm-6">
                        <label>Designation </label><label style="color:red">*</label>
                        <select class="form-control" id="designation" name="designation" required>
                        <option>-- Select option --</option>
                        <?php foreach($data['designation'] as $designation){?>
                                <option value="<?php echo $designation->id;?>" <?php if($data['user_details'][0]->designation==$designation->id){echo 'selected="selected"';}?>><?php echo $designation->designation_name;?></option>
                        <?php } ?>
                        
                        </select>
                        </div>
                    </div>

                   