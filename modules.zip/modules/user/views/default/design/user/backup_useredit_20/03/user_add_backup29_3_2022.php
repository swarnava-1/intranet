<div class="form-group row">
                        <div class="col-sm-6">
                        <label>Designation </label><label style="color:red">*</label>
                        <select class="form-control" required="" id="designation" name="designation" required>
                        <option value="">Select Designation</option>
                        <?php foreach($data['designation'] as $designation){?>
                                <option value="<?php echo $designation->id;?>"><?php echo $designation->designation_name;?></option>
                        <?php } ?>
                        </select>
                        </div>
                    </div>
                     <?php echo $data['leaves'][0]->leave_type;?>:<?php echo $data['leaves'][0]->leave_count;?>
                        <?php echo $data['leaves'][1]->leave_type;?>:<?php echo $data['leaves'][1]->leave_count;?>