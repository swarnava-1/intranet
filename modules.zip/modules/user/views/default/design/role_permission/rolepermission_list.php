
    <div class="float-left mb-3 d-block w-100">
      <h1 class="h3 mb-2 text-gray-800 ">Role Permission</h1>
    </div>
	<!-- <div class="col-md-4 mb-4">
		<select class="form-control">
			<option value="">Role 1</option>
			<option value="">Role 2</option>
			<option value="">Role 3</option>
			<option value="">Role 4</option>
		</select>
	</div> -->
	<div class="form-group row">
                        <div class="col-md-4 mb-4">
                        <label>Role id</label><label style="color:red">*</label>
                        <select class="form-control" required="" id="role_id" name="role_id" required>
                        <option value="">Select Role</option>
                        <?php foreach($data['roles'] as $role){?>
                                <option value="<?php echo $role->id;?>"><?php echo $role->role_name;?></option>
                        <?php } ?>
                        </select>
                        </div>
                    </div>
<div class="hierarchy-checkboxes child-expanded" rel="test">
	  <input class="hierarchy-root-checkbox" type="checkbox">
	  <label class="hierarchy-root-label">Root</label>
	  <div class="hierarchy-root-child hierarchy-node">
	   	<div class="hierarchy-node child-expanded">
	      <input class="hierarchy-checkbox" type="checkbox">
	      <label class="hierarchy-label">Node</label>
	      <div class="hierarchy-node leaf">
	        <input class="hierarchy-checkbox" type="checkbox">
	        <label class="hierarchy-label">Node (Leaf)</label>
	      </div>
	      <div class="hierarchy-node leaf">
	        <input class="hierarchy-checkbox" type="checkbox">
	        <label class="hierarchy-label">Node (Leaf)</label>
	      </div>
	      <div class="hierarchy-node child-expanded">
	        <input class="hierarchy-checkbox" type="checkbox">
	        <label class="hierarchy-label">Node</label>
	        <div class="hierarchy-node leaf">
		        <input class="hierarchy-checkbox" type="checkbox">
		        <label class="hierarchy-label">Node (Leaf)</label>
		      </div>
		      <div class="hierarchy-node leaf">
		        <input class="hierarchy-checkbox" type="checkbox">
		        <label class="hierarchy-label">Node (Leaf)</label>
		      </div>
		      <div class="hierarchy-node leaf">
		        <input class="hierarchy-checkbox" type="checkbox">
		        <label class="hierarchy-label">Node (Leaf)</label>
		      </div>
	      </div>
	      <div class="hierarchy-node leaf">
	        <input class="hierarchy-checkbox" type="checkbox">
	        <label class="hierarchy-label">Node (Leaf)</label>
	      </div>
    	</div>
		
		<div class="hierarchy-node child-expanded">
	      <input class="hierarchy-checkbox" type="checkbox">
	      <label class="hierarchy-label">Node 222</label>
	      <div class="hierarchy-node leaf">
	        <input class="hierarchy-checkbox" type="checkbox">
	        <label class="hierarchy-label">Node (Leaf)</label>
	      </div>
	      <div class="hierarchy-node leaf">
	        <input class="hierarchy-checkbox" type="checkbox">
	        <label class="hierarchy-label">Node (Leaf)</label>
	      </div>
	      <div class="hierarchy-node child-expanded">
	        <input class="hierarchy-checkbox" type="checkbox">
	        <label class="hierarchy-label">Node</label>
	        <div class="hierarchy-node leaf">
		        <input class="hierarchy-checkbox" type="checkbox">
		        <label class="hierarchy-label">Node (Leaf)</label>
		      </div>
		      <div class="hierarchy-node leaf">
		        <input class="hierarchy-checkbox" type="checkbox">
		        <label class="hierarchy-label">Node (Leaf)</label>
		      </div>
		      <div class="hierarchy-node leaf">
		        <input class="hierarchy-checkbox" type="checkbox">
		        <label class="hierarchy-label">Node (Leaf)</label>
		      </div>
	      </div>
	      <div class="hierarchy-node leaf">
	        <input class="hierarchy-checkbox" type="checkbox">
	        <label class="hierarchy-label">Node (Leaf)</label>
	      </div>
    	</div>
		
	    <div class="hierarchy-node leaf">
	      <input class="hierarchy-checkbox" type="checkbox">
	      <label class="hierarchy-label">Node (Leaf)</label>
	    </div>
	    <div class="hierarchy-node leaf">
	      <input class="hierarchy-checkbox" type="checkbox">
	      <label class="hierarchy-label">Node (Leaf)</label>
	    </div>
	    <div class="hierarchy-node leaf">
	      <input class="hierarchy-checkbox" type="checkbox">
	      <label class="hierarchy-label">Node (Leaf)</label>
	    </div>
  	</div>
</div>

	

