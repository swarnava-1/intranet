<div class="container my-auto">
  <div class="copyright text-center my-auto">
    <span>Copyright &copy; centreax <?php echo date('Y');?></span>
  </div>
</div>