
    <div class="row text-gray-900">
        <div class="col-lg-12">
            <div class="card shadow">
                <div class="clearfix card-header">
                    <div class="float-right">
                        <a href="<?php echo base_url('/user/roles_management/')?>" class="btn btn-primary btn-circle pull-right">
                        <i class="fas fa-backward" data-toggle="tooltip" data-placement="bottom" title="Back To role listing Page"></i>
                        </a>
                    </div>
                    <div class="float-left">
                     <h6 class="m-0 font-weight-bold text-primary">Roles Management</h6>
                    </div>                                      
                </div>


                <div class="card-body">                
                <form class="needs-validation" novalidate action="<?php echo site_url('user/roles_management/alterroles/'.$data['id']);?>" method="POST">
                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">           
                    

                    <div class="form-group row">
                        <div class="col-sm-6">
                        <label>Roles Name</label><label style="color:red">*</label>
                        <input type="text" class="form-control" required="" name="role_name" placeholder="Roles Name" required value="<?php echo (isset($data['roles_details']['role_name'])) ?$data['roles_details']['role_name']:"";?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6">
                        <label>Roles Description</label><label style="color:red">*</label>
                        <input type="text" class="form-control" required="" name="description" placeholder="Roles Description" value="<?php echo (isset($data['roles_details']['description'])) ?$data['roles_details']['description']:"";?>">
                        </div>                         
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-6">
                        <label>Roles Status</label><label style="color:red">*</label>
                        <select class="form-control" required name="is_active"> 
                                <option value="1" <?php echo (isset($data['roles_details']) && $data['roles_details']['is_active']=='1') ? "selected":"";?>>Active</option>
                                <option value="0" <?php echo (isset($data['roles_details']) && $data['roles_details']['is_active']=='0') ? "selected":"";?>>Inactive</option>            
                        </select>
                        </div>                        
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6">
                        <label>Is Moderator</label><label style="color:red">*</label>
                        <select class="form-control" required name="is_moderator"> 
                                <option value="1" <?php echo (isset($data['roles_details']) && $data['roles_details']['is_moderator']=='1') ? "selected":"";?>>Yes</option>
                                <option value="0" <?php echo (isset($data['roles_details']) && $data['roles_details']['is_moderator']=='0') ? "selected":"";?>>No</option>            
                        </select>
                        </div>                        
                    </div>
                    <div class="form-group row">
                        
                        <div class="col-sm-3">
                            <input type="submit" class="btn btn-primary btn-user btn-block" value="Submit">
                        </div>
                        <div class="col-sm-3">
                            <input type="reset" id="reset" class="btn btn-user btn-block btn-secondary" value="Reset">
                        </div>                        
                    </div>                    
                </form>
                </div>
            </div>
        </div>    
    </div>
         

